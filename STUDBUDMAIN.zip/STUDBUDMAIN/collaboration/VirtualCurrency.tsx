import React from 'react';
import { Coins, Gift, ShoppingBag, History } from 'lucide-react';

const VirtualCurrency = () => {
  const features = [
    {
      icon: Coins,
      title: 'Study Points',
      description: 'Earn points through academic activities',
    },
    {
      icon: Gift,
      title: 'Rewards Store',
      description: 'Redeem points for exclusive items',
    },
    {
      icon: ShoppingBag,
      title: 'Special Offers',
      description: 'Limited-time deals and bundles',
    },
    {
      icon: History,
      title: 'Transaction History',
      description: 'Track your points and purchases',
    },
  ];

  const storeItems = [
    {
      id: 1,
      name: 'Premium Avatar Pack',
      description: 'Exclusive character customization options',
      price: 1000,
      category: 'Cosmetic',
    },
    {
      id: 2,
      name: 'Study Room Themes',
      description: 'Customize your virtual study environment',
      price: 750,
      category: 'Customization',
    },
    {
      id: 3,
      name: 'Power-up Bundle',
      description: 'Boost your study session effectiveness',
      price: 500,
      category: 'Boost',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Virtual Currency</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Earn study points and redeem them for exclusive rewards and customization options.
          </p>
        </div>

        {/* Current Balance */}
        <div className="bg-white rounded-lg shadow-md p-8 mb-12 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Your Balance</h2>
          <div className="text-4xl font-bold text-blue-600 flex items-center justify-center">
            <Coins className="h-8 w-8 mr-2" />
            2,500 SP
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white rounded-lg shadow-md p-6">
              <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Store Items */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Rewards Store</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {storeItems.map((item) => (
              <div key={item.id} className="border rounded-lg p-4 hover:border-blue-500 transition duration-300">
                <span className="inline-block px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-600 mb-2">
                  {item.category}
                </span>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.name}</h3>
                <p className="text-sm text-gray-600 mb-4">{item.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-blue-600 font-semibold flex items-center">
                    <Coins className="h-4 w-4 mr-1" />
                    {item.price} SP
                  </span>
                  <button className="bg-blue-100 text-blue-600 px-4 py-2 rounded font-medium hover:bg-blue-200 transition duration-300">
                    Purchase
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* View History Button */}
        <div className="text-center mt-8">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            View Transaction History
          </button>
        </div>
      </div>
    </div>
  );
};

export default VirtualCurrency;