import React from 'react';
import { Link } from 'react-router-dom';
import { Users, BookOpen, MessageSquare, Target, Trophy, User } from 'lucide-react';

const Home = () => {
  const collaborationFeatures = [
    {
      icon: Users,
      title: 'Virtual Study Rooms',
      description: 'Join live chat, video sessions, and use interactive whiteboards',
      path: '/virtual-study-rooms',
    },
    {
      icon: BookOpen,
      title: 'Peer-to-Peer Tutoring',
      description: 'Connect with mentors and get answers to your questions',
      path: '/peer-tutoring',
    },
    {
      icon: MessageSquare,
      title: 'Shared Notes & Resources',
      description: 'Collaborate on notes and share study materials',
      path: '/shared-notes',
    },
    {
      icon: Target,
      title: 'Task Delegation',
      description: 'Manage group projects and assign roles effectively',
      path: '/task-delegation',
    },
    {
      icon: MessageSquare,
      title: 'Real-Time Discussions',
      description: 'Engage in discussions and participate in polls',
      path: '/discussions',
    },
  ];

  const gamificationFeatures = [
    {
      icon: Target,
      title: 'Daily & Weekly Challenges',
      description: 'Complete challenges and earn points',
      path: '/challenges',
    },
    {
      icon: Trophy,
      title: 'Leaderboards & Rankings',
      description: 'Compete with peers and climb the rankings',
      path: '/leaderboards',
    },
    {
      icon: User,
      title: 'Avatars & Badges',
      description: 'Customize your profile and earn achievements',
      path: '/avatars',
    },
    {
      icon: Target,
      title: 'Streak Tracking',
      description: 'Maintain your study streak and earn rewards',
      path: '/streak-tracking',
    },
    {
      icon: Trophy,
      title: 'Virtual Currency',
      description: 'Earn and spend virtual currency on perks',
      path: '/virtual-currency',
    },
    {
      icon: Users,
      title: 'Team Competitions',
      description: 'Participate in exciting group battles',
      path: '/team-competitions',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div
        className="relative bg-cover bg-center py-32"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&q=80")',
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Collaboration & Gamification
            <br />
            <span className="text-blue-400">Transform Your Study Experience!</span>
          </h1>
          <p className="text-xl text-gray-200 mb-8 max-w-3xl mx-auto">
            STUDBUD AI revolutionizes learning by making it interactive, social, and fun. Join a community of learners and unlock your full potential through engaging collaboration and exciting gamification features.
          </p>
          <Link
            to="/virtual-study-rooms"
            className="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full text-lg transition duration-300 transform hover:scale-105"
          >
            Join STUDBUD AI Today
          </Link>
        </div>
      </div>

      {/* Collaboration Features Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Collaboration Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {collaborationFeatures.map((feature) => (
              <Link
                key={feature.title}
                to={feature.path}
                className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition duration-300 transform hover:-translate-y-1"
              >
                <feature.icon className="h-12 w-12 text-blue-600 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Gamification Features Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Gamification Features</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {gamificationFeatures.map((feature) => (
              <Link
                key={feature.title}
                to={feature.path}
                className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition duration-300 transform hover:-translate-y-1"
              >
                <feature.icon className="h-12 w-12 text-purple-600 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-blue-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Transform Your Learning Journey?</h2>
          <p className="text-xl text-blue-100 mb-8">Join thousands of students who are already experiencing the future of collaborative learning.</p>
          <Link
            to="/virtual-study-rooms"
            className="inline-block bg-white text-blue-600 font-bold py-3 px-8 rounded-full text-lg transition duration-300 transform hover:scale-105 hover:bg-blue-50"
          >
            Get Started Now
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Home;