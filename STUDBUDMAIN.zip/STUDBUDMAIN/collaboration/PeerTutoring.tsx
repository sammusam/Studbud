import React from 'react';
import { BookOpen, MessageSquare, Video, Calendar } from 'lucide-react';

const PeerTutoring = () => {
  const features = [
    {
      icon: BookOpen,
      title: 'Expert Tutoring',
      description: 'Connect with knowledgeable peers in your subject area',
    },
    {
      icon: MessageSquare,
      title: 'Instant Help',
      description: 'Get quick answers to your academic questions',
    },
    {
      icon: Video,
      title: '1-on-1 Sessions',
      description: 'Schedule private tutoring sessions via video chat',
    },
    {
      icon: Calendar,
      title: 'Flexible Scheduling',
      description: 'Book sessions that fit your timetable',
    },
  ];

  const availableTutors = [
    {
      id: 1,
      name: 'Sarah Chen',
      subject: 'Mathematics',
      rating: 4.9,
      availability: 'Available Now',
      specialization: 'Calculus, Linear Algebra',
    },
    {
      id: 2,
      name: 'James Wilson',
      subject: 'Physics',
      rating: 4.8,
      availability: 'Available in 1 hour',
      specialization: 'Quantum Mechanics, Thermodynamics',
    },
    {
      id: 3,
      name: 'Maria Garcia',
      subject: 'Computer Science',
      rating: 4.7,
      availability: 'Available Now',
      specialization: 'Data Structures, Algorithms',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Peer-to-Peer Tutoring</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Get help from expert peer tutors or become a tutor yourself. Share knowledge, earn rewards, and help others succeed.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white rounded-lg shadow-md p-6">
              <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Become a Tutor Button */}
        <div className="text-center mb-12">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            Become a Tutor
          </button>
        </div>

        {/* Available Tutors */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Available Tutors</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {availableTutors.map((tutor) => (
              <div key={tutor.id} className="border rounded-lg p-4 hover:border-blue-500 transition duration-300">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{tutor.name}</h3>
                <div className="text-sm text-gray-600 space-y-1">
                  <p>Subject: {tutor.subject}</p>
                  <p>Rating: {tutor.rating}/5.0</p>
                  <p>Specialization: {tutor.specialization}</p>
                  <p className="text-green-600 font-medium">{tutor.availability}</p>
                </div>
                <button className="mt-4 w-full bg-blue-100 text-blue-600 px-4 py-2 rounded font-medium hover:bg-blue-200 transition duration-300">
                  Schedule Session
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default PeerTutoring;