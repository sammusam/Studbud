import React from 'react';
import { Flame, Calendar, Award, TrendingUp } from 'lucide-react';

const StreakTracking = () => {
  const features = [
    {
      icon: Flame,
      title: 'Daily Streaks',
      description: 'Maintain your study consistency',
    },
    {
      icon: Calendar,
      title: 'Progress Calendar',
      description: 'Visualize your study patterns',
    },
    {
      icon: Award,
      title: 'Streak Rewards',
      description: 'Earn bonuses for consistency',
    },
    {
      icon: TrendingUp,
      title: 'Performance Stats',
      description: 'Track your improvement over time',
    },
  ];

  const streakStats = [
    {
      id: 1,
      title: 'Current Streak',
      value: 15,
      unit: 'days',
      trend: '+5',
    },
    {
      id: 2,
      title: 'Longest Streak',
      value: 30,
      unit: 'days',
      trend: 'Best',
    },
    {
      id: 3,
      title: 'Total Study Hours',
      value: 120,
      unit: 'hours',
      trend: '+12',
    },
  ];

  const upcomingRewards = [
    {
      id: 1,
      days: 20,
      reward: '500 Bonus Points',
      progress: 75,
    },
    {
      id: 2,
      days: 30,
      reward: 'Golden Scholar Badge',
      progress: 50,
    },
    {
      id: 3,
      days: 50,
      reward: 'Premium Avatar Pack',
      progress: 30,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Streak Tracking</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Stay motivated and consistent with your studies by maintaining your daily streak.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white rounded-lg shadow-md p-6">
              <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Streak Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {streakStats.map((stat) => (
            <div key={stat.id} className="bg-white rounded-lg shadow-md p-6 text-center">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{stat.title}</h3>
              <div className="text-3xl font-bold text-blue-600 mb-1">
                {stat.value} <span className="text-lg">{stat.unit}</span>
              </div>
              <p className={`text-sm font-medium ${
                stat.trend === 'Best' ? 'text-purple-600' : 'text-green-600'
              }`}>
                {stat.trend}
              </p>
            </div>
          ))}
        </div>

        {/* Upcoming Rewards */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Upcoming Rewards</h2>
          <div className="space-y-6">
            {upcomingRewards.map((reward) => (
              <div key={reward.id} className="border rounded-lg p-4">
                <div className="flex justify-between items-center mb-2">
                  <h3 className="text-lg font-semibold text-gray-900">{reward.days} Day Streak</h3>
                  <span className="text-blue-600 font-medium">{reward.reward}</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${reward.progress}%` }}
                  ></div>
                </div>
                <p className="text-sm text-gray-600 mt-2">{reward.progress}% Progress</p>
              </div>
            ))}
          </div>
        </div>

        {/* View Stats Button */}
        <div className="text-center mt-8">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            View Detailed Stats
          </button>
        </div>
      </div>
    </div>
  );
};

export default StreakTracking;