import React from 'react';
import { Trophy, Star, TrendingUp, Medal } from 'lucide-react';

const Leaderboards = () => {
  const features = [
    {
      icon: Trophy,
      title: 'Global Rankings',
      description: 'Compete with students worldwide',
    },
    {
      icon: Star,
      title: 'Subject Leaders',
      description: 'Top performers in each subject',
    },
    {
      icon: TrendingUp,
      title: 'Progress Tracking',
      description: 'Monitor your ranking improvements',
    },
    {
      icon: Medal,
      title: 'Weekly Awards',
      description: 'Special recognition for top achievers',
    },
  ];

  const topPerformers = [
    {
      id: 1,
      rank: 1,
      name: 'Sarah Johnson',
      points: 15420,
      subject: 'Mathematics',
      streak: 45,
    },
    {
      id: 2,
      rank: 2,
      name: 'Michael Chen',
      points: 14890,
      subject: 'Physics',
      streak: 38,
    },
    {
      id: 3,
      rank: 3,
      name: 'Emily Davis',
      points: 14550,
      subject: 'Computer Science',
      streak: 42,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Leaderboards</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Compete with fellow students, climb the rankings, and showcase your academic achievements.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white rounded-lg shadow-md p-6">
              <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Top Performers */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Global Top Performers</h2>
          <div className="space-y-4">
            {topPerformers.map((performer) => (
              <div
                key={performer.id}
                className={`flex items-center border rounded-lg p-4 ${
                  performer.rank === 1 ? 'bg-yellow-50 border-yellow-200' :
                  performer.rank === 2 ? 'bg-gray-50 border-gray-200' :
                  'bg-orange-50 border-orange-200'
                }`}
              >
                <div className={`text-2xl font-bold w-12 h-12 flex items-center justify-center rounded-full ${
                  performer.rank === 1 ? 'bg-yellow-400 text-white' :
                  performer.rank === 2 ? 'bg-gray-400 text-white' :
                  'bg-orange-400 text-white'
                }`}>
                  {performer.rank}
                </div>
                <div className="ml-6 flex-grow">
                  <h3 className="text-lg font-semibold text-gray-900">{performer.name}</h3>
                  <div className="text-sm text-gray-600">
                    <p>Subject: {performer.subject}</p>
                    <p>Points: {performer.points.toLocaleString()}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-600">
                    Streak
                    <p className="text-lg font-semibold text-blue-600">{performer.streak} days</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* View More Button */}
        <div className="text-center mt-8">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            View Full Rankings
          </button>
        </div>
      </div>
    </div>
  );
};

export default Leaderboards;