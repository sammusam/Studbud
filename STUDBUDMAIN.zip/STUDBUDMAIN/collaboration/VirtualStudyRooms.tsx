import React from 'react';
import { Users, Video, MessageSquare, Edit } from 'lucide-react';

const VirtualStudyRooms = () => {
  const features = [
    {
      icon: Users,
      title: 'Group Study Sessions',
      description: 'Join or create study groups with up to 8 participants',
    },
    {
      icon: Video,
      title: 'Video Conferencing',
      description: 'Face-to-face interaction with HD video quality',
    },
    {
      icon: MessageSquare,
      title: 'Live Chat',
      description: 'Real-time messaging with file sharing capabilities',
    },
    {
      icon: Edit,
      title: 'Interactive Whiteboard',
      description: 'Collaborate on a shared digital canvas',
    },
  ];

  const activeRooms = [
    {
      id: 1,
      name: 'Advanced Mathematics',
      participants: 6,
      topic: 'Calculus III',
      status: 'In Progress',
    },
    {
      id: 2,
      name: 'Physics Study Group',
      participants: 4,
      topic: 'Quantum Mechanics',
      status: 'Open',
    },
    {
      id: 3,
      name: 'Computer Science',
      participants: 7,
      topic: 'Data Structures',
      status: 'In Progress',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Virtual Study Rooms</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Connect with fellow students in real-time, share knowledge, and learn together in our interactive virtual study rooms.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white rounded-lg shadow-md p-6">
              <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Create Room Button */}
        <div className="text-center mb-12">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            Create New Study Room
          </button>
        </div>

        {/* Active Rooms */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Active Study Rooms</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeRooms.map((room) => (
              <div key={room.id} className="border rounded-lg p-4 hover:border-blue-500 transition duration-300">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{room.name}</h3>
                <div className="text-sm text-gray-600 space-y-1">
                  <p>Topic: {room.topic}</p>
                  <p>Participants: {room.participants}/8</p>
                  <p>Status: <span className={`font-medium ${room.status === 'Open' ? 'text-green-600' : 'text-blue-600'}`}>{room.status}</span></p>
                </div>
                <button className="mt-4 w-full bg-blue-100 text-blue-600 px-4 py-2 rounded font-medium hover:bg-blue-200 transition duration-300">
                  Join Room
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VirtualStudyRooms;