import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import VirtualStudyRooms from './pages/VirtualStudyRooms';
import PeerTutoring from './pages/PeerTutoring';
import SharedNotes from './pages/SharedNotes';
import TaskDelegation from './pages/TaskDelegation';
import Discussions from './pages/Discussions';
import Challenges from './pages/Challenges';
import Leaderboards from './pages/Leaderboards';
import Avatars from './pages/Avatars';
import StreakTracking from './pages/StreakTracking';
import VirtualCurrency from './pages/VirtualCurrency';
import TeamCompetitions from './pages/TeamCompetitions';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-white">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/virtual-study-rooms" element={<VirtualStudyRooms />} />
          <Route path="/peer-tutoring" element={<PeerTutoring />} />
          <Route path="/shared-notes" element={<SharedNotes />} />
          <Route path="/task-delegation" element={<TaskDelegation />} />
          <Route path="/discussions" element={<Discussions />} />
          <Route path="/challenges" element={<Challenges />} />
          <Route path="/leaderboards" element={<Leaderboards />} />
          <Route path="/avatars" element={<Avatars />} />
          <Route path="/streak-tracking" element={<StreakTracking />} />
          <Route path="/virtual-currency" element={<VirtualCurrency />} />
          <Route path="/team-competitions" element={<TeamCompetitions />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;