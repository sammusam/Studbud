import React from 'react';
import { Users, Target, Trophy, Flag } from 'lucide-react';

const TeamCompetitions = () => {
  const features = [
    {
      icon: Users,
      title: 'Team Formation',
      description: 'Create or join study teams',
    },
    {
      icon: Target,
      title: 'Team Challenges',
      description: 'Compete in group activities',
    },
    {
      icon: Trophy,
      title: 'Team Rankings',
      description: 'Climb the team leaderboard',
    },
    {
      icon: Flag,
      title: 'Team Goals',
      description: 'Set and achieve team objectives',
    },
  ];

  const activeCompetitions = [
    {
      id: 1,
      name: 'Science Bowl',
      teamSize: '4-6',
      participants: 12,
      prize: '2000 SP',
      timeLeft: '3 days',
      difficulty: 'Advanced',
    },
    {
      id: 2,
      name: 'Math League',
      teamSize: '3-4',
      participants: 8,
      prize: '1500 SP',
      timeLeft: '5 days',
      difficulty: 'Intermediate',
    },
    {
      id: 3,
      name: 'Coding Challenge',
      teamSize: '2-3',
      participants: 6,
      prize: '1000 SP',
      timeLeft: '2 days',
      difficulty: 'Advanced',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Team Competitions</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Form teams, compete in challenges, and achieve victory together in exciting academic competitions.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white rounded-lg shadow-md p-6">
              <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Create Team Button */}
        <div className="text-center mb-12">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            Create New Team
          </button>
        </div>

        {/* Active Competitions */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Active Competitions</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeCompetitions.map((competition) => (
              <div key={competition.id} className="border rounded-lg p-4 hover:border-blue-500 transition duration-300">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{competition.name}</h3>
                <div className="text-sm text-gray-600 space-y-1">
                  <p>Team Size: {competition.teamSize} members</p>
                  <p>Teams Participating: {competition.participants}</p>
                  <p>Prize Pool: {competition.prize}</p>
                  <p>Time Left: {competition.timeLeft}</p>
                  <p>Difficulty: <span className={`font-medium ${
                    competition.difficulty === 'Advanced' ? 'text-red-600' : 'text-yellow-600'
                  }`}>{competition.difficulty}</span></p>
                </div>
                <button className="mt-4 w-full bg-blue-100 text-blue-600 px-4 py-2 rounded font-medium hover:bg-blue-200 transition duration-300">
                  Join Competition
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* View Rankings Button */}
        <div className="text-center mt-8">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            View Team Rankings
          </button>
        </div>
      </div>
    </div>
  );
};

export default TeamCompetitions;