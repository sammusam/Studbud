import React from 'react';
import { User, Shield, Palette, Crown } from 'lucide-react';

const Avatars = () => {
  const features = [
    {
      icon: User,
      title: 'Custom Avatars',
      description: 'Create your unique study persona',
    },
    {
      icon: Shield,
      title: 'Achievement Badges',
      description: 'Showcase your academic accomplishments',
    },
    {
      icon: Palette,
      title: 'Customization',
      description: 'Personalize your profile appearance',
    },
    {
      icon: Crown,
      title: 'Special Titles',
      description: 'Earn prestigious academic titles',
    },
  ];

  const avatarStyles = [
    {
      id: 1,
      name: 'Scholar',
      description: 'Classic academic style',
      unlocked: true,
      rarity: 'Common',
    },
    {
      id: 2,
      name: 'Tech Wizard',
      description: 'For the coding enthusiasts',
      unlocked: true,
      rarity: 'Rare',
    },
    {
      id: 3,
      name: 'Science Master',
      description: 'Lab coat and safety goggles',
      unlocked: false,
      rarity: 'Epic',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Avatars & Badges</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Customize your academic identity and showcase your achievements through unique avatars and badges.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white rounded-lg shadow-md p-6">
              <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Avatar Styles */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Available Styles</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {avatarStyles.map((style) => (
              <div key={style.id} className="border rounded-lg p-4 hover:border-blue-500 transition duration-300">
                <div className="flex items-center justify-center w-24 h-24 mx-auto mb-4 bg-blue-100 rounded-full">
                  <User className="h-12 w-12 text-blue-600" />
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2 text-center">{style.name}</h3>
                <p className="text-sm text-gray-600 text-center mb-2">{style.description}</p>
                <div className="flex justify-center gap-2 mb-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    style.rarity === 'Epic' ? 'bg-purple-100 text-purple-600' :
                    style.rarity === 'Rare' ? 'bg-blue-100 text-blue-600' :
                    'bg-gray-100 text-gray-600'
                  }`}>
                    {style.rarity}
                  </span>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    style.unlocked ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                  }`}>
                    {style.unlocked ? 'Unlocked' : 'Locked'}
                  </span>
                </div>
                <button
                  className={`w-full px-4 py-2 rounded font-medium transition duration-300 ${
                    style.unlocked
                      ? 'bg-blue-100 text-blue-600 hover:bg-blue-200'
                      : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  }`}
                  disabled={!style.unlocked}
                >
                  {style.unlocked ? 'Select Style' : 'Unlock Style'}
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Customize Button */}
        <div className="text-center mt-8">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            Customize Avatar
          </button>
        </div>
      </div>
    </div>
  );
};

export default Avatars;