import React from 'react';
import { Target, Award, Clock, Zap } from 'lucide-react';

const Challenges = () => {
  const features = [
    {
      icon: Target,
      title: 'Daily Goals',
      description: 'Complete daily study challenges and earn points',
    },
    {
      icon: Award,
      title: 'Achievements',
      description: 'Unlock badges and rewards for your progress',
    },
    {
      icon: Clock,
      title: 'Time-based Tasks',
      description: 'Race against time to improve your skills',
    },
    {
      icon: Zap,
      title: 'Power-ups',
      description: 'Use boosters to enhance your learning',
    },
  ];

  const activeChallenges = [
    {
      id: 1,
      title: 'Math Marathon',
      description: 'Solve 50 calculus problems',
      points: 500,
      timeLeft: '2 days',
      difficulty: 'Hard',
      participants: 234,
    },
    {
      id: 2,
      title: 'Code Sprint',
      description: 'Complete 10 coding challenges',
      points: 300,
      timeLeft: '1 day',
      difficulty: 'Medium',
      participants: 156,
    },
    {
      id: 3,
      title: 'Science Quiz',
      description: 'Answer 30 physics questions',
      points: 400,
      timeLeft: '3 days',
      difficulty: 'Medium',
      participants: 189,
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Daily Challenges</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Push your limits, compete with peers, and earn rewards through exciting academic challenges.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white rounded-lg shadow-md p-6">
              <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Create Challenge Button */}
        <div className="text-center mb-12">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            Create Challenge
          </button>
        </div>

        {/* Active Challenges */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Active Challenges</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeChallenges.map((challenge) => (
              <div key={challenge.id} className="border rounded-lg p-4 hover:border-blue-500 transition duration-300">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{challenge.title}</h3>
                <p className="text-gray-600 mb-4">{challenge.description}</p>
                <div className="text-sm text-gray-600 space-y-1">
                  <p>Points: <span className="text-blue-600 font-semibold">{challenge.points}</span></p>
                  <p>Time Left: {challenge.timeLeft}</p>
                  <p>Participants: {challenge.participants}</p>
                  <p>Difficulty: <span className={`font-medium ${
                    challenge.difficulty === 'Hard' ? 'text-red-600' :
                    challenge.difficulty === 'Medium' ? 'text-yellow-600' :
                    'text-green-600'
                  }`}>{challenge.difficulty}</span></p>
                </div>
                <button className="mt-4 w-full bg-blue-100 text-blue-600 px-4 py-2 rounded font-medium hover:bg-blue-200 transition duration-300">
                  Join Challenge
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Challenges;