import React from 'react';
import { MessageCircle, Users, ThumbsUp, Bookmark } from 'lucide-react';

const Discussions = () => {
  const features = [
    {
      icon: MessageCircle,
      title: 'Topic Threads',
      description: 'Start discussions on any subject or topic',
    },
    {
      icon: Users,
      title: 'Group Discussions',
      description: 'Participate in subject-specific study groups',
    },
    {
      icon: ThumbsUp,
      title: 'Engagement',
      description: 'Like, reply, and bookmark discussions',
    },
    {
      icon: Bookmark,
      title: 'Bookmarks',
      description: 'Save important discussions for later',
    },
  ];

  const activeDiscussions = [
    {
      id: 1,
      title: 'Understanding Neural Networks',
      author: 'David Kim',
      replies: 15,
      likes: 24,
      lastActive: '10 minutes ago',
      tags: ['AI', 'Machine Learning'],
    },
    {
      id: 2,
      title: 'Solving Complex Integrals',
      author: 'Lisa Chen',
      replies: 8,
      likes: 12,
      lastActive: '30 minutes ago',
      tags: ['Mathematics', 'Calculus'],
    },
    {
      id: 3,
      title: 'JavaScript Best Practices',
      author: 'Mark Wilson',
      replies: 20,
      likes: 35,
      lastActive: '1 hour ago',
      tags: ['Programming', 'Web Development'],
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Discussions</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Engage in meaningful discussions with your peers, share knowledge, and learn from others' experiences.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white rounded-lg shadow-md p-6">
              <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Start Discussion Button */}
        <div className="text-center mb-12">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            Start New Discussion
          </button>
        </div>

        {/* Active Discussions */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Active Discussions</h2>
          <div className="space-y-6">
            {activeDiscussions.map((discussion) => (
              <div key={discussion.id} className="border rounded-lg p-4 hover:border-blue-500 transition duration-300">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{discussion.title}</h3>
                <div className="flex flex-wrap gap-2 mb-3">
                  {discussion.tags.map((tag) => (
                    <span key={tag} className="bg-blue-100 text-blue-600 px-2 py-1 rounded-full text-sm">
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="text-sm text-gray-600 space-y-1">
                  <p>Started by: {discussion.author}</p>
                  <p>Last active: {discussion.lastActive}</p>
                  <div className="flex items-center gap-4 mt-2">
                    <span className="flex items-center gap-1">
                      <MessageCircle className="h-4 w-4" />
                      {discussion.replies} replies
                    </span>
                    <span className="flex items-center gap-1">
                      <ThumbsUp className="h-4 w-4" />
                      {discussion.likes} likes
                    </span>
                  </div>
                </div>
                <button className="mt-4 w-full bg-blue-100 text-blue-600 px-4 py-2 rounded font-medium hover:bg-blue-200 transition duration-300">
                  Join Discussion
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Discussions;