import React from 'react';
import { CheckSquare, Users, Clock, BarChart } from 'lucide-react';

const TaskDelegation = () => {
  const features = [
    {
      icon: CheckSquare,
      title: 'Task Assignment',
      description: 'Assign and track tasks within your study group',
    },
    {
      icon: Users,
      title: 'Team Management',
      description: 'Organize teams and distribute responsibilities',
    },
    {
      icon: Clock,
      title: 'Deadline Tracking',
      description: 'Set and monitor project timelines',
    },
    {
      icon: BarChart,
      title: 'Progress Analytics',
      description: 'Track completion rates and team performance',
    },
  ];

  const activeTasks = [
    {
      id: 1,
      title: 'Research Paper Draft',
      assignee: 'Alex Johnson',
      deadline: '2 days',
      progress: 75,
      priority: 'High',
    },
    {
      id: 2,
      title: 'Presentation Slides',
      assignee: 'Emma Davis',
      deadline: '4 days',
      progress: 40,
      priority: 'Medium',
    },
    {
      id: 3,
      title: 'Data Analysis',
      assignee: 'Michael Smith',
      deadline: '1 week',
      progress: 20,
      priority: 'Low',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Task Delegation</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Efficiently manage group projects by assigning tasks, tracking progress, and meeting deadlines together.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white rounded-lg shadow-md p-6">
              <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Create Task Button */}
        <div className="text-center mb-12">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            Create New Task
          </button>
        </div>

        {/* Active Tasks */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Active Tasks</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {activeTasks.map((task) => (
              <div key={task.id} className="border rounded-lg p-4 hover:border-blue-500 transition duration-300">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{task.title}</h3>
                <div className="text-sm text-gray-600 space-y-1">
                  <p>Assignee: {task.assignee}</p>
                  <p>Deadline: {task.deadline}</p>
                  <p>Progress: {task.progress}%</p>
                  <p>Priority: <span className={`font-medium ${
                    task.priority === 'High' ? 'text-red-600' :
                    task.priority === 'Medium' ? 'text-yellow-600' :
                    'text-green-600'
                  }`}>{task.priority}</span></p>
                </div>
                <div className="mt-4 w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full"
                    style={{ width: `${task.progress}%` }}
                  ></div>
                </div>
                <button className="mt-4 w-full bg-blue-100 text-blue-600 px-4 py-2 rounded font-medium hover:bg-blue-200 transition duration-300">
                  View Details
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TaskDelegation;