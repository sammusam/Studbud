import React from 'react';
import { FileText, Share2, Users, History } from 'lucide-react';

const SharedNotes = () => {
  const features = [
    {
      icon: FileText,
      title: 'Real-time Editing',
      description: 'Collaborate on notes simultaneously with your peers',
    },
    {
      icon: Share2,
      title: 'Easy Sharing',
      description: 'Share notes with specific users or study groups',
    },
    {
      icon: Users,
      title: 'Group Access',
      description: 'Manage permissions and access controls',
    },
    {
      icon: History,
      title: 'Version History',
      description: 'Track changes and restore previous versions',
    },
  ];

  const recentNotes = [
    {
      id: 1,
      title: 'Advanced Calculus Notes',
      subject: 'Mathematics',
      contributors: 3,
      lastUpdated: '5 minutes ago',
    },
    {
      id: 2,
      title: 'Quantum Physics Study Guide',
      subject: 'Physics',
      contributors: 2,
      lastUpdated: '1 hour ago',
    },
    {
      id: 3,
      title: 'Data Structures Summary',
      subject: 'Computer Science',
      contributors: 4,
      lastUpdated: '2 hours ago',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Shared Notes</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Create, share, and collaborate on notes in real-time. Keep your study materials organized and accessible.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {features.map((feature) => (
            <div key={feature.title} className="bg-white rounded-lg shadow-md p-6">
              <feature.icon className="h-8 w-8 text-blue-600 mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>

        {/* Create Note Button */}
        <div className="text-center mb-12">
          <button className="bg-blue-600 text-white px-8 py-3 rounded-full font-semibold text-lg hover:bg-blue-700 transition duration-300">
            Create New Note
          </button>
        </div>

        {/* Recent Notes */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Recent Notes</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recentNotes.map((note) => (
              <div key={note.id} className="border rounded-lg p-4 hover:border-blue-500 transition duration-300">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{note.title}</h3>
                <div className="text-sm text-gray-600 space-y-1">
                  <p>Subject: {note.subject}</p>
                  <p>Contributors: {note.contributors}</p>
                  <p>Last updated: {note.lastUpdated}</p>
                </div>
                <button className="mt-4 w-full bg-blue-100 text-blue-600 px-4 py-2 rounded font-medium hover:bg-blue-200 transition duration-300">
                  Open Note
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SharedNotes;