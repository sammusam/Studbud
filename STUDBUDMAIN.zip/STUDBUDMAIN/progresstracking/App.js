import React, { useState, useEffect } from "react";
import "./App.css";

const initialCourses = [
  {
    id: 1,
    title: "React Basics",
    lessons: [
      { id: 1, title: "Introduction to React", completed: false },
      { id: 2, title: "Components and Props", completed: false },
      { id: 3, title: "State and Lifecycle", completed: false },
    ],
  },
  {
    id: 2,
    title: "Advanced React",
    lessons: [
      { id: 4, title: "Hooks", completed: false },
      { id: 5, title: "Context API", completed: false },
    ],
  },
  {
    id: 3,
    title: "JavaScript Fundamentals",
    lessons: [
      { id: 11, title: "Variables and Data Types", completed: false },
      { id: 12, title: "Functions and Scope", completed: false },
      { id: 13, title: "Arrays and Objects", completed: false },
      { id: 14, title: "ES6 Features", completed: false },
      { id: 15, title: "Asynchronous JavaScript", completed: false },
    ],
  },
  {
    id: 4,
    title: "HTML and CSS",
    lessons: [
      { id: 16, title: "HTML Basics", completed: false },
      { id: 17, title: "CSS Selectors and Box Model", completed: false },
      { id: 18, title: "Flexbox and Grid", completed: false },
      { id: 19, title: "Responsive Design", completed: false },
      { id: 20, title: "CSS Animations", completed: false },
    ],
  },
  {
    id: 5,
    title: "Node.js and Express",
    lessons: [
      { id: 21, title: "Introduction to Node.js", completed: false },
      { id: 22, title: "Building REST APIs", completed: false },
      { id: 23, title: "Middleware in Express", completed: false },
      { id: 24, title: "Error Handling", completed: false },
      { id: 25, title: "Authentication and Authorization", completed: false },
    ],
  },
  {
    id: 6,
    title: "Database Management",
    lessons: [
      { id: 26, title: "SQL Basics", completed: false },
      { id: 27, title: "MongoDB and NoSQL", completed: false },
      { id: 28, title: "Database Design", completed: false },
      { id: 29, title: "ORM with Sequelize", completed: false },
      { id: 30, title: "Database Optimization", completed: false },
    ],
  },
  {
    id: 7,
    title: "DevOps and Deployment",
    lessons: [
      { id: 31, title: "Introduction to DevOps", completed: false },
      { id: 32, title: "Docker Basics", completed: false },
      { id: 33, title: "Kubernetes", completed: false },
      { id: 34, title: "CI/CD Pipelines", completed: false },
      { id: 35, title: "Cloud Deployment", completed: false },
    ],
  },
  {
    id: 8,
    title: "Testing in React",
    lessons: [
      { id: 36, title: "Unit Testing with Jest", completed: false },
      { id: 37, title: "Testing React Components", completed: false },
      { id: 38, title: "End-to-End Testing with Cypress", completed: false },
      { id: 39, title: "Mocking API Calls", completed: false },
      { id: 40, title: "Test Coverage", completed: false },
    ],
  },
  {
    id: 9,
    title: "State Management",
    lessons: [
      { id: 41, title: "Redux Basics", completed: false },
      { id: 42, title: "Redux Toolkit", completed: false },
      { id: 43, title: "Context API vs Redux", completed: false },
      { id: 44, title: "Recoil", completed: false },
      { id: 45, title: "State Management Best Practices", completed: false },
    ],
  },
  {
    id: 10,
    title: "Advanced JavaScript",
    lessons: [
      { id: 46, title: "Closures and Prototypes", completed: false },
      { id: 47, title: "Promises and Async/Await", completed: false },
      { id: 48, title: "Generators and Iterators", completed: false },
      { id: 49, title: "Memory Management", completed: false },
      { id: 50, title: "Design Patterns", completed: false },
    ],
  },
];

const App = () => {
  const [courses, setCourses] = useState(initialCourses);
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [darkMode, setDarkMode] = useState(false);
  const [points, setPoints] = useState(0); // Track user points
  const [streak, setStreak] = useState(0); // Track current streak
  const [longestStreak, setLongestStreak] = useState(0); // Track longest streak
  const [lastCompletedDate, setLastCompletedDate] = useState(null); // Track last completion date
  const [badges, setBadges] = useState([]); // Track earned badges

  // Load progress from local storage
  useEffect(() => {
    const savedProgress = JSON.parse(localStorage.getItem("studentProgress"));
    if (savedProgress) {
      setCourses(savedProgress);
    }
    const savedGamification = JSON.parse(localStorage.getItem("gamification"));
    if (savedGamification) {
      setPoints(savedGamification.points);
      setStreak(savedGamification.streak);
      setLongestStreak(savedGamification.longestStreak);
      setLastCompletedDate(savedGamification.lastCompletedDate);
      setBadges(savedGamification.badges);
    }
  }, []);

  // Save progress and gamification data to local storage
  useEffect(() => {
    localStorage.setItem("studentProgress", JSON.stringify(courses));
    localStorage.setItem(
      "gamification",
      JSON.stringify({ points, streak, longestStreak, lastCompletedDate, badges })
    );
  }, [courses, points, streak, longestStreak, lastCompletedDate, badges]);

  // Mark a lesson as completed
  const markLessonCompleted = (courseId, lessonId) => {
    const updatedCourses = courses.map((course) =>
      course.id === courseId
        ? {
            ...course,
            lessons: course.lessons.map((lesson) =>
              lesson.id === lessonId ? { ...lesson, completed: true } : lesson
            ),
          }
        : course
    );

    setCourses(updatedCourses);

    // Award points for completing a lesson
    setPoints((prevPoints) => prevPoints + 10); // Award 10 points per lesson

    // Update streaks
    const today = new Date().toDateString();
    if (lastCompletedDate !== today) {
      const newStreak = lastCompletedDate === getYesterdayDate() ? streak + 1 : 1;
      setStreak(newStreak);
      if (newStreak > longestStreak) {
        setLongestStreak(newStreak);
      }
      setLastCompletedDate(today);
    }

    // Check for badges
    checkForBadges(updatedCourses);
  };

  // Helper function to get yesterday's date
  const getYesterdayDate = () => {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    return yesterday.toDateString();
  };

  // Check for badges based on milestones
  const checkForBadges = (courses) => {
    const totalCompletedLessons = courses.reduce(
      (sum, course) => sum + course.lessons.filter((lesson) => lesson.completed).length,
      0
    );

    const newBadges = [];
    if (totalCompletedLessons >= 10 && !badges.includes("10 Lessons Completed")) {
      newBadges.push("10 Lessons Completed");
    }
    if (totalCompletedLessons >= 50 && !badges.includes("50 Lessons Completed")) {
      newBadges.push("50 Lessons Completed");
    }
    if (totalCompletedLessons >= 100 && !badges.includes("100 Lessons Completed")) {
      newBadges.push("100 Lessons Completed");
    }

    if (newBadges.length > 0) {
      setBadges((prevBadges) => [...prevBadges, ...newBadges]);
    }
  };

  // Calculate course progress
  const calculateCourseProgress = (course) => {
    const completedLessons = course.lessons.filter((lesson) => lesson.completed).length;
    const totalLessons = course.lessons.length;
    return totalLessons === 0 ? 0 : (completedLessons / totalLessons) * 100;
  };

  // Filter courses based on search and filter
  const filteredCourses = courses.filter((course) => {
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter =
      filter === "all" || (filter === "completed" && calculateCourseProgress(course) === 100);
    return matchesSearch && matchesFilter;
  });

  // Toggle dark mode
  useEffect(() => {
    document.body.classList.toggle("dark-mode", darkMode);
  }, [darkMode]);

  // Register the service worker
  useEffect(() => {
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker
        .register("/service-worker.js")
        .then((registration) => {
          console.log("Service Worker registered:", registration);
        })
        .catch((error) => {
          console.log("Service Worker registration failed:", error);
        });
    }
  }, []);

  return (
    <div className={`app ${darkMode ? "dark-mode" : ""}`}>
      <h1>Student Progress Tracker</h1>
      <button onClick={() => setDarkMode(!darkMode)}>
        Toggle Dark Mode
      </button>

      {/* Gamification Dashboard */}
      <div className="gamification-dashboard">
        <h2>Gamification</h2>
        <p>Points: {points}</p>
        <p>Current Streak: {streak} day(s)</p>
        <p>Longest Streak: {longestStreak} day(s)</p>
        <p>Badges: {badges.join(", ")}</p>
      </div>

      <input
        type="text"
        placeholder="Search courses..."
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />
      <select value={filter} onChange={(e) => setFilter(e.target.value)}>
        <option value="all">All</option>
        <option value="completed">Completed</option>
      </select>

      {/* Display courses and lessons */}
      {filteredCourses.map((course) => (
        <div key={course.id} className="course-card">
          <h2>{course.title}</h2>
          <p>Progress: {calculateCourseProgress(course).toFixed(2)}%</p>
          <ul>
            {course.lessons.map((lesson) => (
              <li key={lesson.id}>
                {lesson.title} - {lesson.completed ? "Completed" : "Not Completed"}{" "}
                <button onClick={() => markLessonCompleted(course.id, lesson.id)}>
                  Mark as Completed
                </button>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
};

export default App;